package template_service

import (
	"Template-golang/model/request"
	"Template-golang/model/response"
)

func Template_Service(Request request.Request) (response.Response, error) {

	var res response.Response

	return res, nil
}
