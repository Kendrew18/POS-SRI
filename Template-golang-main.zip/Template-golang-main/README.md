# Template-golang
## install echo https://echo.labstack.com/guide/#installation
## install tkanos https://github.com/tkanos/gonfig
## install SQL-Driver https://github.com/go-sql-driver/mysql
