package request

type Request struct {
	Id   string `json:"id"`
	Nama string `json:"nama"`
}
